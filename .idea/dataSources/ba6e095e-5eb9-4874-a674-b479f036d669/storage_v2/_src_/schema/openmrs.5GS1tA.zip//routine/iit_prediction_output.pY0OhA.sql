create
    definer = root@localhost procedure iit_prediction_output()
BEGIN
	  CREATE TABLE iit_prediction_output (
	    iit_prediction_output_id INT (11) NOT NULL AUTO_INCREMENT,
	    patient_id INT (11) NOT NULL,
	    art_intiation_date DATETIME,
	    current_art_regiment VARCHAR (1024),
	    current_regiment_intiation DATETIME,
	    last_dispense_date DATETIME,
	    last_dispense_amount INT (11),
	    num_iit_last_12 INT (11),
	    num_iit_total INT (11),
	    duration_of_last_iit INT (11),
	    time_since_last_iit INT (11),
	    last_vl_date DATETIME,
	    last_vl_result INT (11),
	    iit_prediction INT (11),
	    patient_status VARCHAR (1024),
	    iit_data_csv TEXT,
      pills_remaininv_csv LONGTEXT,
      vl_results_csv  TEXT,
	    PRIMARY KEY (iit_prediction_output_id)
	  ) ENGINE = INNODB DEFAULT CHARSET = utf8; 
END;

