create
    definer = root@localhost function getdaysofarvrefil(obsid decimal, obsgroupid decimal, valuenumeric decimal) returns decimal
BEGIN
DECLARE ans NUMERIC;
    IF obsid=obsgroupid THEN
        SET ans = valuenumeric;
    ELSE
         SET ans = NULL;
    END IF;
RETURN ans;
END;

