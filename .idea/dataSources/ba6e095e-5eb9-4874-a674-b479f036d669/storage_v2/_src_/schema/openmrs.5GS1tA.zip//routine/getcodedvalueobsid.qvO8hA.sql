create
    definer = root@localhost function getcodedvalueobsid(obsid int) returns text
BEGIN
    DECLARE val TEXT;
    SELECT  cn.name INTO val FROM
		obs
		INNER JOIN concept_name cn ON(obs.value_coded=cn.concept_id AND cn.locale='en' AND cn.locale_preferred=1) WHERE obs.obs_id=obsid;
	RETURN val;
END;

