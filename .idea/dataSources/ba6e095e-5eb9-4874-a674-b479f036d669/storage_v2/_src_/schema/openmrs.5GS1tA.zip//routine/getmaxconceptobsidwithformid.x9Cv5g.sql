create
    definer = root@localhost function getmaxconceptobsidwithformid(patientid int, conceptid int, formid int, cutoffdate date) returns decimal
BEGIN
    DECLARE value_num INT;
    SELECT  obs.obs_id INTO value_num FROM obs INNER JOIN encounter ON(encounter.encounter_id=obs.encounter_id AND encounter.voided=0) WHERE  encounter.form_id=formid AND obs.person_id=patientid
		AND obs.concept_id=conceptid AND obs.voided=0 AND obs.obs_datetime<=cutoffdate ORDER BY obs.obs_datetime DESC LIMIT 1;
	RETURN value_num;
END;

