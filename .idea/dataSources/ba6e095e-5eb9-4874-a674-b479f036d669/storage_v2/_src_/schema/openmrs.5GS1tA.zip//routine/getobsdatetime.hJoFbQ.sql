create
    definer = root@localhost function getobsdatetime(obsid int) returns date
BEGIN
    DECLARE val DATE;
    SELECT  obs.obs_datetime INTO val FROM obs WHERE  obs.obs_id=obsid;
	RETURN val;
END;

