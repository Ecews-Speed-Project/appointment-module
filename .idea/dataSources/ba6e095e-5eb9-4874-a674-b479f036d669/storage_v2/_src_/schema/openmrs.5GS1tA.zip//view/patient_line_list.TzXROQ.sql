create definer = root@localhost view patient_line_list as
select (select count(`openmrs`.`encounter`.`encounter_type`)
        from `openmrs`.`encounter`
        where ((`openmrs`.`encounter`.`encounter_type` = 13) and
               (`openmrs`.`encounter`.`patient_id` = `p`.`patient_id`))) AS `encounterTypePhamacy`,
       (select count(`openmrs`.`encounter`.`encounter_type`)
        from `openmrs`.`encounter`
        where ((`openmrs`.`encounter`.`encounter_type` = 11) and
               (`openmrs`.`encounter`.`patient_id` = `p`.`patient_id`))) AS `encounterTypeLab`,
       (select concat(`pn`.`given_name`, ' ', `pn`.`family_name`)
        from `openmrs`.`person_name` `pn`
        where ((`pn`.`person_id` = `p`.`patient_id`) and (`pn`.`preferred` = 1))
        limit 1)                                                         AS `personName`,
       (select `pid`.`identifier`
        from `openmrs`.`patient_identifier` `pid`
        where ((`pid`.`patient_id` = `p`.`patient_id`) and (`pid`.`preferred` = 1))
        limit 1)                                                         AS `identifier`,
       (select `fe`.`encounter_datetime`
        from `openmrs`.`encounter` `fe`
        where (`fe`.`patient_id` = `p`.`patient_id`)
        order by `fe`.`encounter_datetime`
        limit 1)                                                         AS `dateOfFirstEncounter`,
       (select `obs`.`answer`
        from `openmrs`.`obs_view` `obs`
        where ((`obs`.`person_id` = `p`.`patient_id`) and (`obs`.`concept_id` = 165724))
        order by (`obs`.`encounter_datetime` and (`obs`.`encounter_datetime` is not null))
        limit 1)                                                         AS `firstDocumentedRegimen`,
       (select `obs`.`answer`
        from `openmrs`.`obs_view` `obs`
        where ((`obs`.`person_id` = `p`.`patient_id`) and (`obs`.`concept_id` = 165724))
        order by (`obs`.`encounter_datetime` and (`obs`.`encounter_datetime` is not null)) desc
        limit 1)                                                         AS `LastdocumentedRegimen`,
       (select `le`.`encounter_datetime`
        from `openmrs`.`encounter` `le`
        where (`le`.`patient_id` = `p`.`patient_id`)
        order by `le`.`encounter_datetime` desc
        limit 1)                                                         AS `dateOfLastEncounter`
from `openmrs`.`patient` `p`;

