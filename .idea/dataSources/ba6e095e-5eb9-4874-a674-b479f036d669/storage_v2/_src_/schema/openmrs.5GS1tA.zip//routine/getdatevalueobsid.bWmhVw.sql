create
    definer = root@localhost function getdatevalueobsid(obsid int) returns date
BEGIN
    DECLARE val DATE;
    SELECT  obs.value_datetime INTO val FROM obs WHERE  obs.obs_id=obsid;
	RETURN val;
END;

