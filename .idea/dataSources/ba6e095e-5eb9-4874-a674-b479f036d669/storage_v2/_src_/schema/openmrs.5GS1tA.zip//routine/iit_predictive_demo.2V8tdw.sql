create
    definer = root@localhost procedure iit_predictive_demo(IN patientid varchar(255))
BEGIN
  CREATE TABLE iit_predictive_demo AS
  SELECT
    pid1.identifier AS `patient_id`,
    (SELECT
        DATE(ob.`value_datetime`)
      FROM
        `obs` ob
        JOIN encounter e
          ON ob.encounter_id = e.encounter_id
      WHERE ob.`concept_id` IN (159599)
        AND ob.`person_id` = patient.`patient_id`
        AND e.encounter_type = 25
        AND ob.voided = 0
        AND e.voided = 0
      LIMIT 1) AS 'art_start_date',
      (SELECT
        CASE WHEN ob.`value_numeric` IS NOT NULL THEN ob.`value_numeric`
        ELSE '0'
        END
      FROM
        `obs` ob
        JOIN encounter e
          ON ob.encounter_id = e.encounter_id
      WHERE ob.`concept_id` IN (165582)
        AND ob.`person_id` = patient.`patient_id`
        AND e.encounter_type = 25
        AND ob.voided = 0
        AND e.voided = 0
      LIMIT 1) AS 'weight_at_art_start',
      ( SELECT
  CASE WHEN cn.`name` = 'Death' THEN '1'
  ELSE '0'
  END
   FROM `obs` ob  JOIN `concept_name` cn ON cn.`concept_id` = ob.value_coded JOIN encounter e ON ob.encounter_id=e.encounter_id
     WHERE ob.`concept_id` = 165470  AND cn.`locale` = 'en' AND cn.`locale_preferred` = 1
     AND ob.`person_id` =  patient.`patient_id`
     AND e.encounter_type=15
     AND ob.voided=0
     AND e.voided=0
     ORDER BY ob.obs_datetime DESC LIMIT 1) AS 'patient_has_died',
     (SELECT property_value FROM global_property WHERE property='partner_short_name' ) AS IP,
     DATE(person.`birthdate`) AS 'dob',
     person.`gender` AS 'sex',
     (SELECT
        DATE(ob.`value_datetime`)
      FROM
        `obs` ob
        JOIN encounter e
          ON ob.encounter_id = e.encounter_id
      WHERE ob.`concept_id` IN (160554)
        AND ob.`person_id` = patient.`patient_id`
        AND e.encounter_type = 14
        AND ob.voided = 0
        AND e.voided = 0
      LIMIT 1) AS 'diagnosis_date',
      (SELECT `name` FROM `address_hierarchy_entry` WHERE `level_id`=3 AND `user_generated_id` =
      (SELECT property_value FROM global_property WHERE property='partner_reporting_lga_code' )) AS 'lga_name',
      (SELECT property_value FROM global_property WHERE property='Facility_Name' ) AS 'facility_name',
      (SELECT `name` FROM `address_hierarchy_entry` WHERE `level_id`=2 AND `user_generated_id` =
      (SELECT property_value FROM global_property WHERE property='partner_reporting_state' )) AS 'State',
      (SELECT IF(TIMESTAMPDIFF(YEAR,person.birthdate,ob.value_datetime)>=5,@ageAtStart:=TIMESTAMPDIFF(YEAR,person.birthdate,ob.value_datetime),@ageAtStart:=0)
  FROM `obs` ob JOIN encounter e ON ob.encounter_id=e.encounter_id
     WHERE ob.`concept_id` IN (159599)
     AND ob.`value_datetime`
     AND ob.`person_id` =  patient.`patient_id`
     AND e.encounter_type=25
     AND ob.voided=0
     AND e.voided=0
     LIMIT 1) AS 'age_at_art_start',
     (SELECT COUNT(encounter_datetime) FROM encounter e JOIN obs o ON e.encounter_id = o.encounter_id WHERE e.`patient_id`= `patient`.`patient_id`
    AND `e`.`encounter_type`=13 AND `e`.`voided`=0 AND o.`concept_id` IN (164507,164514,165703,164506,164513,165702)  AND o.voided=0) AS 'total_drug_pick_up',
    (SELECT COUNT(encounter_datetime) FROM encounter e JOIN obs o ON e.encounter_id = o.encounter_id WHERE e.`patient_id`= `patient`.`patient_id`
    AND `e`.`encounter_type`=11 AND `e`.`voided`=0 AND o.`concept_id` IN (856)  AND o.voided=0) AS 'total_vl_test'
  FROM
    patient
    INNER JOIN patient_identifier pid1
      ON (
        pid1.patient_id = patient.patient_id
        AND patient.voided = 0 AND pid1.identifier_type = 4 AND pid1.voided = 0 AND pid1.identifier = patientid
      )
  INNER JOIN person ON(person.person_id=patient.patient_id)
  WHERE patient.voided = 0
  GROUP BY patient.patient_id
  HAVING art_start_date IS NOT NULL
  AND total_drug_pick_up > 1
  AND total_vl_test > 0 ;
  END;

