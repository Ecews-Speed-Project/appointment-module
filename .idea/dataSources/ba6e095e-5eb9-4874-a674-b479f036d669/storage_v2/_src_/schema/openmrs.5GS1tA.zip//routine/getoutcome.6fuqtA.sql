create
    definer = root@localhost function getoutcome(lastpickupdate date, daysofarvrefill decimal, ltfudays decimal,
                                                 enddate date) returns text
BEGIN
        DECLARE  ltfudate DATE;
        DECLARE  ltfunumber NUMERIC;
        DECLARE  daysdiff NUMERIC;
        DECLARE outcome TEXT;
        SET ltfunumber=daysofarvrefill+ltfudays;
        SELECT DATE_ADD(lastpickupdate, INTERVAL ltfunumber DAY) INTO ltfudate;
        SELECT DATEDIFF(ltfudate,enddate) INTO daysdiff;
        SELECT IF(daysdiff >=0,"Active","LTFU") INTO outcome;
        RETURN outcome;
END;

