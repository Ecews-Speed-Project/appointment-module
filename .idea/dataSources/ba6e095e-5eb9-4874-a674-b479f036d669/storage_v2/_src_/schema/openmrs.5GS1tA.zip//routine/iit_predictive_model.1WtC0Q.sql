create
    definer = root@localhost procedure iit_predictive_model(IN patientid varchar(255))
BEGIN
  CREATE TABLE iit_predictive_model AS
  SELECT
    pid1.identifier AS `PepID`,
    (SELECT
      CASE
        WHEN cn.`name` = 'No signs or symptoms of disease'
        THEN 'No symptoms'
        WHEN cn.`name` = 'Disease suspected'
        THEN 'Presumptive TB'
        WHEN cn.`name` = 'Currently on INH prophylaxis'
        THEN 'On_TPT'
        WHEN cn.`name` = 'Disease diagnosed'
        THEN 'Confirmed/On treatment'
        WHEN cn.`name` = 'On treatment for disease'
        THEN 'Confirmed/On treatment'
      END
    FROM
      `obs` ob
      JOIN `concept_name` cn
        ON cn.`concept_id` = ob.value_coded
      JOIN encounter e
        ON ob.encounter_id = e.encounter_id
    WHERE ob.`concept_id` = 1659
      AND cn.`locale` = 'en'
      AND cn.`locale_preferred` = 1
      AND ob.`person_id` = patient.`patient_id`
      AND e.encounter_type = 12
      AND ob.voided = 0
      AND e.voided = 0
    ORDER BY ob.obs_datetime DESC
    LIMIT 1) AS `TB_Status`,
    (SELECT
      CASE
        WHEN cn.`name` = 'Child 1st line ARV regimen'
        THEN 'First line'
        WHEN cn.`name` = 'Child 2nd line ARV regimen'
        THEN 'Second line'
        WHEN cn.`name` = 'Child 3rd Line ARV Regimens'
        THEN 'Third line'
        WHEN cn.`name` = 'Adult 1st line ARV regimen'
        THEN 'First line'
        WHEN cn.`name` = 'Adult 2nd line ARV regimen'
        THEN 'Second line'
        WHEN cn.`name` = 'Adult 3rd Line ARV Regimens'
        THEN 'Third line'
      END
    FROM
      `obs` ob
      JOIN `concept_name` cn
        ON cn.`concept_id` = ob.value_coded
      JOIN encounter e
        ON ob.encounter_id = e.encounter_id
    WHERE ob.`concept_id` = 165708
      AND cn.`locale` = 'en'
      AND cn.`locale_preferred` = 1
      AND ob.`person_id` = patient.`patient_id`
      AND e.encounter_type = 13
      AND ob.voided = 0
      AND e.voided = 0
    ORDER BY ob.obs_datetime DESC
    LIMIT 1) AS `Last_Drug_Regimen`,
    DATEDIFF(
      (SELECT
        DATE(`value_datetime`)
      FROM
        `obs` ob
        JOIN encounter e
          ON ob.encounter_id = e.encounter_id
      WHERE ob.`concept_id` IN (160554)
        AND ob.`person_id` = patient.`patient_id`
        AND e.encounter_type = 14
        AND ob.voided = 0
        AND e.voided = 0
      LIMIT 1),
      (SELECT
        DATE(`value_datetime`)
      FROM
        `obs` ob
        JOIN encounter e
          ON ob.encounter_id = e.encounter_id
      WHERE ob.`concept_id` IN (159599)
        AND ob.`person_id` = patient.`patient_id`
        AND e.encounter_type = 25
        AND ob.voided = 0
        AND e.voided = 0
      LIMIT 1)
    ) AS `ART_delay`,
    (SELECT
      CASE
        WHEN cn.`name` = 'Physically able to work'
        THEN 'Working'
        WHEN cn.`name` = 'Bedridden'
        THEN 'Bedridden'
        WHEN cn.`name` = 'Patient ambulatory'
        THEN 'Ambulatory'
      END
    FROM
      `obs` ob
      JOIN `concept_name` cn
        ON cn.`concept_id` = ob.value_coded
      JOIN encounter e
        ON ob.encounter_id = e.encounter_id
    WHERE ob.`concept_id` = 165039
      AND cn.`locale` = 'en'
      AND cn.`locale_preferred` = 1
      AND ob.`person_id` = patient.`patient_id`
      AND e.encounter_type = 12
      AND ob.voided = 0
      AND e.voided = 0
    ORDER BY ob.obs_datetime DESC
    LIMIT 1) AS `Functional_Status`,
    (SELECT
      CASE
        WHEN cn.`name` = 'Unemployed'
        THEN 'Unemployed'
        WHEN cn.`name` = 'Employee'
        THEN 'Employed'
        WHEN cn.`name` = 'Student'
        THEN 'Student'
        WHEN cn.`name` = 'Retired'
        THEN 'Retired'
      END
    FROM
      `obs` ob
      JOIN `concept_name` cn
        ON cn.`concept_id` = ob.value_coded
      JOIN encounter e
        ON ob.encounter_id = e.encounter_id
    WHERE ob.`concept_id` = 1542
      AND cn.`locale` = 'en'
      AND cn.`locale_preferred` = 1
      AND ob.`person_id` = patient.`patient_id`
      AND e.encounter_type = 14
      AND ob.voided = 0
      AND e.voided = 0
    ORDER BY ob.obs_datetime DESC
    LIMIT 1) AS `Occupation`,
    (SELECT
      CASE
        WHEN cn.`name` = 'Never married'
        THEN 'Unmarried/Single'
        WHEN cn.`name` = 'Married'
        THEN 'Living together/Married'
        WHEN cn.`name` = 'Divorced'
        THEN 'Separated/Divorced'
        WHEN cn.`name` = 'Separated'
        THEN 'Separated/Divorced'
        WHEN cn.`name` = 'Living with partner'
        THEN 'Living together/Mrried'
        WHEN cn.`name` = 'Widowed'
        THEN 'Widowed'
      END
    FROM
      `obs` ob
      JOIN `concept_name` cn
        ON cn.`concept_id` = ob.value_coded
      JOIN encounter e
        ON ob.encounter_id = e.encounter_id
    WHERE ob.`concept_id` = 1054
      AND cn.`locale` = 'en'
      AND cn.`locale_preferred` = 1
      AND ob.`person_id` = patient.`patient_id`
      AND e.encounter_type = 14
      AND ob.voided = 0
      AND e.voided = 0
    ORDER BY ob.obs_datetime DESC
    LIMIT 1) AS `Marital_Status`,
    (SELECT
      CASE
         WHEN cn.`name` = 'None'
        THEN 'None'
        WHEN cn.`name` = 'Primary school education'
        THEN 'Primary'
        WHEN cn.`name` = 'Secondary school education'
        THEN 'Junior Secondary'
        WHEN cn.`name` = 'Secondary school education'
        THEN 'Senior Secondary'
        WHEN cn.`name` = 'Tertiary education complete'
        THEN 'Post Secondary'
         WHEN cn.`name` = 'Other'
        THEN 'None'
      END
    FROM
      `obs` ob
      JOIN `concept_name` cn
        ON cn.`concept_id` = ob.value_coded
      JOIN encounter e
        ON ob.encounter_id = e.encounter_id
    WHERE ob.`concept_id` = 1712
      AND cn.`locale` = 'en'
      AND cn.`locale_preferred` = 1
      AND ob.`person_id` = patient.`patient_id`
      AND e.encounter_type = 14
      AND ob.voided = 0
      AND e.voided = 0
    ORDER BY ob.obs_datetime DESC
    LIMIT 1) AS `Education_level`,
    CASE
      WHEN person.`gender` = 'M'
      THEN 'Male'
      WHEN person.`gender` = 'F'
      THEN 'Female'
    END AS `Gender`,
    (SELECT
      ob.value_numeric
    END
    FROM
      `obs` ob
      JOIN encounter e
        ON ob.encounter_id = e.encounter_id
    WHERE ob.`concept_id` = 5089
      AND ob.`person_id` = patient.`patient_id`
      AND e.encounter_type = 12
      AND ob.voided = 0
      AND e.voided = 0
    ORDER BY ob.obs_datetime DESC
    LIMIT 1) AS `Weight`,
    (SELECT
      ob.value_numeric
    FROM
      `obs` ob
      JOIN encounter e
        ON ob.encounter_id = e.encounter_id
    WHERE ob.`concept_id` IN (856)
      AND ob.`person_id` = patient.`patient_id`
      AND e.encounter_type = 11
      AND ob.voided = 0
      AND e.voided = 0
    ORDER BY ob.obs_datetime DESC
    LIMIT 1) AS `CurrentViralLoad`,
    TIMESTAMPDIFF(YEAR, person.birthdate, CURDATE()) AS `Current_Age`,
    DATEDIFF(
      (SELECT
        DATE(MAX(e.encounter_datetime))
      FROM
        encounter e
      WHERE e.patient_id = patient.`patient_id`
        AND e.encounter_type = 13
        AND e.voided = 0
      LIMIT 1),
      (SELECT
        DATE(ob.`value_datetime`)
      FROM
        `obs` ob
        JOIN encounter e
          ON ob.encounter_id = e.encounter_id
      WHERE ob.`concept_id` IN (159599)
        AND ob.`person_id` = patient.`patient_id`
        AND e.encounter_type = 25
        AND ob.voided = 0
        AND e.voided = 0
      LIMIT 1)
    ) AS `Duration_on_treatment`,
    person.person_id AS `patient_id`,
CASE
    WHEN (
      TO_DAYS(CURDATE()) - (
        TO_DAYS(
          ((SELECT
        DATE(MAX(e.encounter_datetime))
      FROM
        encounter e
      WHERE e.patient_id = patient.`patient_id`
        AND e.encounter_type = 13
        AND e.voided = 0
      LIMIT 1)) + INTERVAL ((SELECT
        ob.`value_numeric`
      FROM
        `obs` ob
        JOIN encounter e
          ON ob.encounter_id = e.encounter_id
      WHERE ob.`concept_id` IN (159368)
        AND ob.`person_id` = patient.`patient_id`
        AND e.encounter_type = 13
        AND ob.voided = 0
        AND e.voided = 0 ORDER BY e.encounter_datetime DESC
      LIMIT 1)) DAY
        )
      )
    ) <= 28
    THEN 'Active'
    ELSE 'Inactive'
  END AS CurrentStatus28Days,
  (SELECT
        ob.`value_numeric`
      FROM
        `obs` ob
        JOIN encounter e
          ON ob.encounter_id = e.encounter_id
      WHERE ob.`concept_id` IN (159368)
        AND ob.`person_id` = patient.`patient_id`
        AND e.encounter_type = 13
        AND ob.voided = 0
        AND e.voided = 0 ORDER BY e.encounter_datetime DESC
      LIMIT 1) AS days_of_arv_refill,
   IF((SELECT
      CASE
        WHEN cn.`name` = 'Pregnant'
        THEN 'Pregnant'
        WHEN cn.`name` = 'Breastfeeding'
        THEN 'Not_pregnant'
        WHEN cn.`name` = 'Not Pregnant'
        THEN 'Not_pregnant'
      END
    FROM
      `obs` ob
      JOIN `concept_name` cn
        ON cn.`concept_id` = ob.value_coded
      JOIN encounter e
        ON ob.encounter_id = e.encounter_id
    WHERE ob.`concept_id` = 165050
      AND cn.`locale` = 'en'
      AND cn.`locale_preferred` = 1
      AND ob.`person_id` = patient.`patient_id`
      AND e.encounter_type = 12
      AND ob.voided = 0
      AND e.voided = 0
    ORDER BY ob.obs_datetime DESC
    LIMIT 1) IS NOT NULL, (SELECT
      CASE
        WHEN cn.`name` = 'Pregnant'
        THEN 'Pregnant'
        WHEN cn.`name` = 'Breastfeeding'
        THEN 'Not_pregnant'
        WHEN cn.`name` = 'Not Pregnant'
        THEN 'Not_pregnant'
      END
    FROM
      `obs` ob
      JOIN `concept_name` cn
        ON cn.`concept_id` = ob.value_coded
      JOIN encounter e
        ON ob.encounter_id = e.encounter_id
    WHERE ob.`concept_id` = 165050
      AND cn.`locale` = 'en'
      AND cn.`locale_preferred` = 1
      AND ob.`person_id` = patient.`patient_id`
      AND e.encounter_type = 12
      AND ob.voided = 0
      AND e.voided = 0
    ORDER BY ob.obs_datetime DESC
    LIMIT 1), 'Not_pregnant' ) AS `pregnancy_status`,
    "1" AS is_surge_site,
    (SELECT `name` FROM `address_hierarchy_entry` WHERE `level_id`=2 AND `user_generated_id` =
      (SELECT property_value FROM global_property WHERE property='partner_reporting_state' )) as state_name
  FROM
    patient
    INNER JOIN patient_identifier pid1
      ON (
        pid1.patient_id = patient.patient_id
        AND patient.voided = 0 AND pid1.identifier_type = 4 AND pid1.voided = 0  AND pid1.identifier = patientid
      )
    INNER JOIN person
      ON (
        person.person_id = patient.patient_id
      )
  WHERE patient.voided = 0
  GROUP BY patient.patient_id
  HAVING TB_Status IS NOT NULL
    AND Last_Drug_Regimen IS NOT NULL
    AND ART_delay IS NOT NULL
    AND Functional_Status IS NOT NULL
    AND Occupation IS NOT NULL
    AND Marital_Status IS NOT NULL
    AND Education_level IS NOT NULL
    AND Gender IS NOT NULL
    AND Weight IS NOT NULL
    AND CurrentViralLoad IS NOT NULL
    AND Current_Age IS NOT NULL
    AND Duration_on_treatment IS NOT NULL ;
END;

