create
    definer = root@localhost procedure iit_predictive_lab(IN patientid varchar(255))
BEGIN
  CREATE TABLE iit_predictive_lab AS
 SELECT
    pid1.identifier AS `patient_id`,
   DATE(e.encounter_datetime) AS 'date',
     (SELECT `name` FROM `address_hierarchy_entry` WHERE `level_id`=2 AND `user_generated_id` =
      (SELECT property_value FROM global_property WHERE property='partner_reporting_state' )) AS 'state_name',
      DATE(obs.`date_created`) AS 'created_at',
    MAX(IF(obs.concept_id=856,obs.value_numeric,NULL)) AS 'VLresult'
  FROM
  encounter e LEFT JOIN
    patient ON e.`patient_id` = `patient`.`patient_id`
    INNER JOIN patient_identifier pid1
      ON (
        pid1.patient_id = patient.patient_id
        AND patient.voided = 0 AND pid1.identifier_type = 4 AND pid1.voided = 0 AND pid1.identifier = patientid
      )
  LEFT JOIN `obs` ON (`obs`.`encounter_id` = e.`encounter_id`) AND obs.voided=0 
  LEFT JOIN concept_name cn ON(obs.value_coded=cn.concept_id AND cn.locale='en' AND cn.locale_preferred=1)
  WHERE patient.voided = 0 
  AND e.`encounter_type` = 11 
  AND `e`.`voided`=0 
  GROUP BY e.`encounter_id`,patient.patient_id
  HAVING VLresult IS NOT NULL
     AND `date` IS NOT NULL
     AND (SELECT
        ob.value_numeric
      FROM
        `obs` ob
        JOIN encounter e
          ON ob.encounter_id = e.encounter_id
      WHERE ob.`concept_id` IN (856)
        AND ob.`person_id` = patient.`patient_id`
        AND e.encounter_type = 11
        AND ob.voided = 0
        AND e.voided = 0
        ORDER BY ob.obs_datetime DESC
      LIMIT 1) IS NOT NULL ;
 END;

