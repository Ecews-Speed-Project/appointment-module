create
    definer = root@localhost function getmaxconceptobsid(patientid int, conceptid int, cutoffdate date) returns decimal
BEGIN
    DECLARE value_num INT;
    SELECT  obs.obs_id INTO value_num FROM obs WHERE  obs.person_id=patientid AND obs.concept_id=conceptid AND obs.voided=0 AND
	obs.obs_datetime<=cutoffdate ORDER BY obs.obs_datetime DESC LIMIT 1;
	RETURN value_num;
END;

