create definer = root@localhost view obs_view as
select `openmrs`.`obs`.`person_id`   AS `person_id`,
       `openmrs`.`obs`.`concept_id`  AS `concept_id`,
       (select `openmrs`.`encounter`.`encounter_datetime`
        from `openmrs`.`encounter`
        where (`openmrs`.`encounter`.`encounter_id` = `openmrs`.`obs`.`encounter_id`)
        limit 1)                     AS `encounter_datetime`,
       (select `concept_view`.`NAME`
        from `openmrs`.`concept_view`
        where (`concept_view`.`concept_id` = `openmrs`.`obs`.`concept_id`)
        limit 1)                     AS `question`,
       (select `concept_view`.`NAME`
        from `openmrs`.`concept_view`
        where (`concept_view`.`concept_id` = `openmrs`.`obs`.`value_coded`)
        limit 1)                     AS `answer`,
       `openmrs`.`obs`.`value_coded` AS `value_coded`
from `openmrs`.`obs`;

