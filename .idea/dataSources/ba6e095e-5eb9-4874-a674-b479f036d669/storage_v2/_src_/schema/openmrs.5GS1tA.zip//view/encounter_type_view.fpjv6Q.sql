create definer = root@localhost view encounter_type_view as
select `e`.`encounter_type`                                      AS `EncounterTypeId`,
       (select `et`.`name`
        from `openmrs`.`encounter_type` `et`
        where (`et`.`encounter_type_id` = `e`.`encounter_type`)) AS `EncounterType`,
       count(`e`.`encounter_type`)                               AS `NumberOfEncounters`
from `openmrs`.`encounter` `e`
group by `e`.`encounter_type`;

