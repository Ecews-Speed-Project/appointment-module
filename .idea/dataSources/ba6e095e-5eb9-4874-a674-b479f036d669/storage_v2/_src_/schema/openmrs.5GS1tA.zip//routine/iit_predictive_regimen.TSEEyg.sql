create
    definer = root@localhost procedure iit_predictive_regimen(IN patientid varchar(255))
BEGIN
  CREATE TABLE iit_predictive_regimen AS
  SELECT
    pid1.identifier AS `patient_id`,
   DATE(e.encounter_datetime) AS 'date',
    MAX(IF(obs.concept_id IN (164507,164514,165703,164506,164513,165702),cn.name,NULL)) AS 'regimen_description',
    MAX(IF(obs.concept_id=159368,obs.value_numeric,NULL)) AS 'regimen_duration',
      CASE
        WHEN MAX(IF(obs.concept_id=165708,cn.name,NULL)) = 'Child 1st line ARV regimen'
        THEN '1'
        WHEN MAX(IF(obs.concept_id=165708,cn.name,NULL)) = 'Child 2nd line ARV regimen'
        THEN '2'
        WHEN MAX(IF(obs.concept_id=165708,cn.name,NULL)) = 'Child 3rd Line ARV Regimens'
        THEN '3'
        WHEN MAX(IF(obs.concept_id=165708,cn.name,NULL)) = 'Adult 1st line ARV regimen'
        THEN '1'
        WHEN MAX(IF(obs.concept_id=165708,cn.name,NULL)) = 'Adult 2nd line ARV regimen'
        THEN '2'
        WHEN MAX(IF(obs.concept_id=165708,cn.name,NULL)) = 'Adult 3rd Line ARV Regimens'
        THEN '3'
        ELSE '0'
      END AS 'regimen_line',
    (SELECT
        DATE(ob.`value_datetime`)
      FROM
        `obs` ob
        JOIN encounter e
          ON ob.encounter_id = e.encounter_id
      WHERE ob.`concept_id` IN (159599)
        AND ob.`person_id` = patient.`patient_id`
        AND e.encounter_type = 25
        AND ob.voided = 0
        AND e.voided = 0
      LIMIT 1) AS 'init_regimen_date',
   (SELECT
      cn.`name`
    FROM
      `obs` ob
      JOIN `concept_name` cn
        ON cn.`concept_id` = ob.value_coded
      JOIN encounter e
        ON ob.encounter_id = e.encounter_id
    WHERE ob.`concept_id` IN (164507,164514,165703,164506,164513,165702)
      AND cn.`locale` = 'en'
      AND cn.`locale_preferred` = 1
      AND ob.`person_id` = patient.`patient_id`
      AND e.encounter_type = 25
      AND ob.voided = 0
      AND e.voided = 0
    ORDER BY ob.obs_datetime DESC
    LIMIT 1) AS 'init_regimen_description',
    (SELECT COUNT(encounter_datetime) FROM encounter WHERE encounter.`patient_id`= `patient`.`patient_id` 
    AND `encounter`.`encounter_type`=13 AND `encounter`.`voided`=0) AS 'total_drug_pick_up'
  FROM
  encounter e LEFT JOIN
    patient ON e.`patient_id` = `patient`.`patient_id`
    INNER JOIN patient_identifier pid1
      ON (
        pid1.patient_id = patient.patient_id
        AND patient.voided = 0 AND pid1.identifier_type = 4 AND pid1.voided = 0 AND pid1.identifier = patientid
      )
  LEFT JOIN `obs` ON (`obs`.`encounter_id` = e.`encounter_id`) AND obs.voided=0 
  LEFT JOIN concept_name cn ON(obs.value_coded=cn.concept_id AND cn.locale='en' AND cn.locale_preferred=1)
  WHERE patient.voided = 0 
  AND e.`encounter_type` = 13 
  AND `e`.`voided`=0 
  GROUP BY e.`encounter_id`,patient.patient_id
  HAVING regimen_description IS NOT NULL
     AND init_regimen_date IS NOT NULL 
     AND (SELECT
        ob.value_numeric
      FROM
        `obs` ob
        JOIN encounter e
          ON ob.encounter_id = e.encounter_id
      WHERE ob.`concept_id` IN (856)
        AND ob.`person_id` = patient.`patient_id`
        AND e.encounter_type = 11
        AND ob.voided = 0
        AND e.voided = 0
        ORDER BY ob.obs_datetime DESC
      LIMIT 1) IS NOT NULL
      AND total_drug_pick_up > 1;
 END;

