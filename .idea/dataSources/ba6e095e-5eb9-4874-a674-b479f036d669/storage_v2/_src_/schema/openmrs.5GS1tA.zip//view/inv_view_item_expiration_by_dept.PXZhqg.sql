create definer = root@localhost view inv_view_item_expiration_by_dept as
select `c`.`consumption_id`                                                  AS `consumption_id`,
       `b`.`item_id`                                                         AS `item_id`,
       `b`.`expiration`                                                      AS `expiration`,
       (`b`.`quantity` - coalesce(sum((`c`.`quantity` + `c`.`wastage`)), 0)) AS `quantity`,
       `a`.`department_id`                                                   AS `department_id`
from ((`openmrs`.`inv_stock_operation` `a` join `openmrs`.`inv_stock_operation_item` `b`
       on (((`a`.`stock_operation_id` = `b`.`operation_id`) and
            (`a`.`department_id` is not null)))) left join `openmrs`.`inv_consumption` `c`
      on (((`b`.`item_batch` = `c`.`batch_number`) and (`a`.`department_id` = `c`.`department_id`))))
group by `b`.`item_batch`, `b`.`expiration`, `a`.`department_id`;

