create definer = root@localhost view inv_view_stockroom_stockonhand as
select `tb1`.`stock_operation_id`                    AS `stock_operation_id`,
       `tb2`.`item_batch`                            AS `item_batch`,
       `tb2`.`expiration`                            AS `expiration`,
       `tb1`.`department_id`                         AS `department_id`,
       `tb1`.`commodity_type`                        AS `commodity_type`,
       date_format(`tb1`.`date_created`, '%Y-%m-%d') AS `date_created`,
       `tb1`.`qtyReceived`                           AS `qtyReceived`,
       `tb2`.`qtyDistribute`                         AS `qtyDistribute`,
       (`tb1`.`qtyReceived` - `tb2`.`qtyDistribute`) AS `quantity`,
       `tb2`.`item_id`                               AS `item_id`
from (((select `a`.`stock_operation_id` AS `stock_operation_id`,
               `b`.`item_batch`         AS `item_batch`,
               `b`.`expiration`         AS `expiration`,
               `a`.`department_id`      AS `department_id`,
               `a`.`commodity_type`     AS `commodity_type`,
               `a`.`date_created`       AS `date_created`,
               sum(`b`.`quantity`)      AS `qtyReceived`,
               `b`.`item_id`            AS `item_id`
        from (`openmrs`.`inv_stock_operation` `a` join `openmrs`.`inv_stock_operation_item` `b`
              on ((`a`.`stock_operation_id` = `b`.`operation_id`)))
        where ((`a`.`operation_type_id` = 4) and (`a`.`commodity_type` = 'pharmacy'))
        group by `b`.`item_id`
        order by `b`.`item_id`)) `tb1` join (select `a`.`stock_operation_id` AS `stock_operation_id`,
                                                    `b`.`item_batch`         AS `item_batch`,
                                                    `b`.`expiration`         AS `expiration`,
                                                    `a`.`department_id`      AS `department_id`,
                                                    `a`.`commodity_type`     AS `commodity_type`,
                                                    `a`.`date_created`       AS `date_created`,
                                                    sum(`b`.`quantity`)      AS `qtyDistribute`,
                                                    `b`.`item_id`            AS `item_id`
                                             from (`openmrs`.`inv_stock_operation` `a` join `openmrs`.`inv_stock_operation_item` `b`
                                                   on ((`a`.`stock_operation_id` = `b`.`operation_id`)))
                                             where ((`a`.`operation_type_id` = 3) and (`a`.`commodity_type` = 'pharmacy'))
                                             group by `b`.`item_id`
                                             order by `b`.`item_id`, `a`.`department_id`) `tb2`
      on ((`tb1`.`item_id` = `tb2`.`item_id`)));

