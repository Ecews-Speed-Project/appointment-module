create definer = root@localhost view concept_view as
select `c`.`concept_id` AS `concept_id`, `cn`.`name` AS `NAME`, `cn`.`locale_preferred` AS `locale_preferred`
from (`openmrs`.`concept_name` `cn` join `openmrs`.`concept` `c` on ((`c`.`concept_id` = `cn`.`concept_id`)))
where ((`cn`.`locale_preferred` = 1) and (`cn`.`locale` = 'en'));

